<?php
//header('Content-Type: text/event-stream');
//header('Cache-Control: no-cache');

//echo"$current_town";
//$productid = $_SESSION['productid'];
if(isset($_POST['pollingunit'])){
    $polling_unit = $conn->real_escape_string($_POST['pollingunit']);
    $user = $conn->real_escape_string($_POST['user']);

$date = date("Y-m-d h:i:s");

 $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';

   // echo $ipaddress;


if(isset($_POST['pdp'])){
$party = $_POST['pdp'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','PDP','$party','$user','$date','$ipaddress')";
	    $select= $conn->query($sql);

}

if(isset($_POST['dpp'])){
$party = $_POST['dpp'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','DPP','$party','$user','$date','$ipaddress')";
	    $select= $conn->query($sql);
}

if(isset($_POST['acn'])){
$party = $_POST['acn'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','ACN','$party','$user','$date','$ipaddress')";
    
    	$select= $conn->query($sql);

}

if(isset($_POST['ppa'])){
$party = $_POST['ppa'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','PPA','$party','$user','$date','$ipaddress')";
   
   	 	$select= $conn->query($sql);

}

if(isset($_POST['cdc'])){
$party = $_POST['cdc'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','CDC','$party','$user','$date','$ipaddress')";

	    $select= $conn->query($sql);

}
if(isset($_POST['jp'])){
$party = $_POST['jp'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','JP','$party','$user','$date','$ipaddress')";

	    $select= $conn->query($sql);

}

if(isset($_POST['anpp'])){
$party = $_POST['anpp'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','ANPP','$party','$user','$date','$ipaddress')";
    	
    	$select= $conn->query($sql);

}

if(isset($_POST['labour'])){
$party = $_POST['labour'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','LABO','$party','$user','$date','$ipaddress')";
	   
	    $select= $conn->query($sql);

}

if(isset($_POST['cpp'])){
$party = $_POST['cpp'];
	$sql = "insert into announced_pu_results (polling_unit_uniqueid,party_abbreviation,party_score,entered_by_user, date_entered, user_ip_address) values ('$polling_unit','CPP','$party','$user','$date','$ipaddress')";
	
	    $select= $conn->query($sql);

}

	if($select){
		echo" <div class='text-center alert-success log-status-container' style='color:blue'><span>Your have successfully added a polling unit result</span> </div>";
}else{
		echo" <div class='text-center alert-danger log-status-container' style='color:red'><span>Incomplete credentials</span> </div>";

}

}
//$sql = "select * from polling_unit where polling_unit_id NOT IN (select polling_unit_uniqueid from announced_pu_results) and polling_unit_id!='0'";


?>