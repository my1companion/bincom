<?php
class bincom{
	protected $servername = "localhost";
	protected $username = "root";
    protected $password = "";
    protected $database = "bincom";

// Create connection;;
    public function __construct(){
			    $this->connect_db =new mysqli($this->servername, $this->username, $this->password, $this->database);
	}
	
    public function connect(){ 
	   //  $connect_db =new mysqli($this->servername, $this->username, $this->password, $this->database);
		 
/*   $sql = "select * from reg_tb";
	     $result = $this->connect_db->query($sql);
	if($result->num_rows > 0){
	echo"doneonnected";
	}  */
		 	if ( mysqli_connect_errno() ) {
			printf("Connection failed: %s\
", mysqli_connect_error());
			exit();
			
		}
		return true;
	 }
	
  
	
//$conn=mysqli_connect("localhost","root","","mycompanion_db") or die ("Unable to connect");
}

?>