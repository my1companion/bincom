<?php
session_start();
header('Content-Type: application/json; chraset=UTF-8');
//header('Content-Type: text/event-stream');
//header('Cache-Control: no-cache');
require("dbcon.php");

$obj = new bincom;
$conn = $obj->connect_db;
//echo"$current_town";
//$productid = $_SESSION['productid'];

$sql = "select partyid, partyname from party";

    $select= $conn->query($sql);
$outp = array();
$outp = $select->fetch_all(MYSQLI_ASSOC);

	


//$count =$select->num_rows();
//echo "data:".json_encode($outp)."\n\n";
echo json_encode($outp);
//ob_flush();

//flush();


?>