<?php
session_start();
header('Content-Type: application/json; chraset=UTF-8');
//header('Content-Type: text/event-stream');
//header('Cache-Control: no-cache');
require("dbcon.php");

$obj = new bincom;
$conn = $obj->connect_db;
//echo"$current_town";
//$productid = $_SESSION['productid'];

$sql = "select DISTINCT pu_result.polling_unit_uniqueid, pu.polling_unit_name from announced_pu_results pu_result join polling_unit pu on(pu.uniqueid=pu_result.polling_unit_uniqueid)";

//$sql = "select * from polling_unit where polling_unit_id NOT IN (select polling_unit_uniqueid from announced_pu_results) and polling_unit_id!='0'";

    $select= $conn->query($sql);
$outp = array();
$outp = $select->fetch_all(MYSQLI_ASSOC);

	


//$count =$select->num_rows();
//echo "data:".json_encode($outp)."\n\n";
echo json_encode($outp);
//ob_flush();

//flush();


?>