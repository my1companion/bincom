<?php
session_start();
header('Content-Type: application/json; chraset=UTF-8');
//header('Content-Type: text/event-stream');
//header('Cache-Control: no-cache');
require("dbcon.php");

$obj = new bincom;
$conn = $obj->connect_db;
//echo"$current_town";
//$productid = $_SESSION['productid'];
    $polling_unit = $conn->real_escape_string($_POST['pollingunit']);

$sql = "select  announced_pu_results.party_abbreviation, announced_pu_results.party_score, polling_unit.polling_unit_name from announced_pu_results  join polling_unit on(announced_pu_results.polling_unit_uniqueid= polling_unit.uniqueid) where polling_unit_uniqueid='$polling_unit'";

    $select= $conn->query($sql);
$outp = array();
$outp = $select->fetch_all(MYSQLI_ASSOC);

	


//$count =$select->num_rows();
//echo "data:".json_encode($outp)."\n\n";
echo json_encode($outp);
//ob_flush();

//flush();


?>