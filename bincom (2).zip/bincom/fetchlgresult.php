<?php
session_start();
header('Content-Type: application/json; chraset=UTF-8');
//header('Content-Type: text/event-stream');
//header('Cache-Control: no-cache');
require("dbcon.php");

$obj = new bincom;
$conn = $obj->connect_db;
//echo"$current_town";
//$productid = $_SESSION['productid'];
    $local_gov = $conn->real_escape_string($_POST['localgov']);

$sql = "select SUM(result.party_score) as party_score, result.party_abbreviation from polling_unit pu join announced_pu_results result on (result.polling_unit_uniqueid=pu.polling_unit_id) join lga on(lga.lga_id=pu.lga_id) where pu.lga_id='$local_gov'  GROUP BY result.party_abbreviation";

    $select= $conn->query($sql);
$outp = array();
$outp = $select->fetch_all(MYSQLI_ASSOC);

	


//$count =$select->num_rows();
//echo "data:".json_encode($outp)."\n\n";
echo json_encode($outp);
//ob_flush();

//flush();


?>