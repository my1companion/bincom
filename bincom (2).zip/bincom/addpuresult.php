<?php
session_start();
require("dbcon.php");

$obj = new bincom;
$conn = $obj->connect_db;


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Bincom</title>
	<link rel="stylesheet" href="fontawesome/css/all.min.css"> <!-- https://fontawesome.com/ -->
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet"> <!-- https://fonts.google.com/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-xtra-blog.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/fix-it.png" type="image/x-icon">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	 <nav class="navbar navbar-expand-lg stroke px-0 hidden-lg">
                <h1 class="text-center ml-5">
                    <a class="navbar text-center" href="index.html" style="color:#ff4c00">
                          
                    </a>
                   
                </h1>

               
                    </nav>
	<header class="tm-header" id="tm-header">
           
                </div>
                <!-- //toggle switch for light and dark theme -->
            </nav>		
        <div class="tm-header-wrapper">
            <button class="navbar-toggler" type="button" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="tm-site-header">
                <div class="mb-3 mx-auto tm-site-logo">                	   
</div>            
                <h1 class="text-center">Bincom</h1>

            </div>
            <nav class="tm-nav" id="tm-nav">            
                <ul>
                    <li class="tm-nav-item "><a href="index.php" class="tm-nav-link">
                        <i class="fas fa-home"></i>
                         Polling Unit Result
                    </a></li>
                    <li class="tm-nav-item"><a href="lgresult.php" class="tm-nav-link">
                        Total Result of Polling Unit
                    </a></li>
                    <li class="tm-nav-item active"><a href="addpuresult.php" class="tm-nav-link">
                        <i class="fas fa-users"></i>
                        Add New Polling Unit
                    </a></li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container-fluid">
        <main class="tm-main">
            <!-- Search form -->
            <div class="row tm-row">
                <div class="col-12 mb-5">
                    <h2>Add Polling Unit Result</h2>
                </div>                
            </div>            
<?php
include("addpuresultprocess.php");

?>            <div class="row tm-row" id="postsContainer">

                <form id="form" action="addpuresult.php" method="post">

                <select id="pollingUnit" class="form-control" required="" name="pollingunit">

                    <option selected disabled="" value="">Select Polling Unit</option>

                </select>

                <div class='form-group'><label for='user'>User</label><input type='text'  class='form-control' id='user' name='user' placeholder='Enter user name' required=''></div>

                </form>



            </div>

            <div class="row tm-row" id="resultContainer">



            </div>



            <footer class="row tm-row">
                <hr class="col-12">
                <div class="col-md-6 col-12 tm-color-gray">
                </div>
                <div class="col-md-6 col-12 tm-color-gray tm-copyright">
                </div>
            </footer>
        </main>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/templatemo-script.js"></script>
    <script src="js/myscript.js"></script>
    <script type="text/javascript">

        fetchPollingUnits();
        fetchParties();
        
    </script>    
    <script>
  function readURL(input, imgV) {

        if (input.files && input.files[0]) {

            var reader = new FileReader();

            reader.onload = function (e) {
                $('#'+imgV)
                    .attr('src', e.target.result)
                    
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>

<!-- to prevent resubmission -->
    <script>
        if ( window.history.replaceState ) {
            window.history.replaceState( null, null, window.location.href );
        }
    </script>    

</body>
</html>