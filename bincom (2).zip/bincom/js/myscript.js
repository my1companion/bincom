// JavaScript Document
	//productDisplay.innerHTML+= "<p>yy</p>";
function fetchPollingUnits(){

        jQuery(document).ready(function($) {    

        $.post("fetchpollingunits.php",{},function(response){ 

            for(x=0;x<response.length;x++){

              document.getElementById('pollingUnit').innerHTML += "<option value='"+response[x].polling_unit_uniqueid+"'>"+response[x].polling_unit_name+"</option>";


            }

        }); 
        }); 

}


function fetchResult(){


//get polling unit id
    var pollingUnit = document.getElementById('pollingUnit').value;

    if(pollingUnit!=""){
        jQuery(document).ready(function($) {    

            var result = "";

            $.post("fetchresult.php",{pollingunit:pollingUnit},function(response){ 

             document.getElementById('resultContainer').innerHTML = "<h3 class='m-3'>Showing results for '"+response[0].polling_unit_name+"' polling unit</h3><table class='table table-striped' ><thead><tr><th>Party Name</th><th>Party Score</th></tr></thead><tbody id='table'>";           
                for(x=0;x<response.length;x++){

                     document.getElementById('table').innerHTML += "<tr ><td>"+response[x].party_abbreviation+"</td><td>"+response[x].party_score+"</td></tr>";
                     


                }

             document.getElementById('resultContainer').innerHTML += "</tbody></table>";           

        }); 
        }); 
    }else{
        alert("Please select a polling unit to fetch results")
    }
}

function fetchLocalGovernment(){

        jQuery(document).ready(function($) {    

        $.post("fetchlocalgovernment.php",{},function(response){ 

            for(x=0;x<response.length;x++){

              document.getElementById('localGov').innerHTML += "<option value='"+response[x].lga_id+"'>"+response[x].lga_name+"</option>";


            }

        }); 
        }); 

}

function fetchLgResult(){


//get lga id
    var lg = document.getElementById('localGov').value;


    if(lg!=""){
        jQuery(document).ready(function($) {    

            var result = "";

            $.post("fetchlgresult.php",{localgov:lg},function(response){ 


                if(response.length>0){


             document.getElementById('resultContainer').innerHTML = "<table class='table table-striped' ><thead><tr><th>Part Name</th><th>Part Score</th></tr></thead><tbody id='table'>";           
                for(x=0;x<response.length;x++){

                     document.getElementById('table').innerHTML += "<tr ><td>"+response[x].party_abbreviation+"</td><td>"+response[x].party_score+"</td></tr>";
                     


                }

             document.getElementById('resultContainer').innerHTML += "</tbody></table>";           
            }else{
               document.getElementById('resultContainer').innerHTML = "<p>No result for selected Local Government</p>";  
            }
        }); 
        }); 
    }else{
        alert("Please select a polling unit to fetch results")
    }
}


function fetchParties(){

        jQuery(document).ready(function($) {    

        $.post("fetchparties.php",{},function(response){ 

            for(x=0;x<response.length;x++){

              document.getElementById('form').innerHTML += "<div class='form-group'><label for='party"+response[x].partyname+"'>"+response[x].partyname+" Score</label><input type='number'  class='form-control' id='party"+response[x].partyname+"' name='"+response[x].partyname.toLowerCase()+"' placeholder='Enter "+response[x].partyname+" score' required=''></div>";


            }
            document.getElementById('form').innerHTML += "<div class='form-group float-right'><input type='submit'  class='form-control btn text-white' required='' value='Submit Result' style='background-color:#ff4c00'></div>";
        }); 
        }); 

}
